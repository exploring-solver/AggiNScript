# File: mypackage/__init__.py

print("Initializing mypackage")

# This code will run when the 'mypackage' package is imported